package com.example.intentcondatos;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    private Button b1;
    private TextView txt1;

    public static final String valor ="valor";


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        b1=findViewById(R.id.b1);
        txt1=findViewById(R.id.txt1);

    }

    public void siguiente(View view)
    {
        Intent miintent=new Intent(this,Registro.class);
        startActivity(miintent);
    }
}