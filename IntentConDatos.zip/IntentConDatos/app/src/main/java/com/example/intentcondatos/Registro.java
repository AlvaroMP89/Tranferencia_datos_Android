package com.example.intentcondatos;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class Registro extends AppCompatActivity {

    private EditText nom1;
    private EditText con1;

    private Button b3;

    public static final String usuario = "usuario";
    public static final String contrasena = "contrasena";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registro2);

        nom1=findViewById(R.id.nom1);
        con1=findViewById(R.id.con1);
        b3=findViewById(R.id.b3);
    }
    public void siguiente1 (View view)
    {
        String usuario=nom1.getText().toString();
        String contrasena1=con1.getText().toString();

        Intent miintent=new Intent(this,registro3.class);
        miintent.putExtra("usuario",usuario);
        miintent.putExtra("contrasena",contrasena1);

        startActivity(miintent);

    }
}