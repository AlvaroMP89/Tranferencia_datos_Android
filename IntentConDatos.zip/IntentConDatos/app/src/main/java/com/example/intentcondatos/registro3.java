package com.example.intentcondatos;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class registro3 extends AppCompatActivity {

    private TextView text3;

    private TextView con4;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registro3);

        text3=findViewById(R.id.text3);
        con4=findViewById(R.id.con4);

        Intent miintent=getIntent();
        String texto3=miintent.getStringExtra(Registro.usuario);
        String cont4=miintent.getStringExtra(Registro.contrasena);

        text3.setText(texto3);
        con4.setText(cont4);

    }
    public void volver (View view)
    {
        finish();;
    }
}